function clicked() {

}

function moved() {

}

function released() {

}

function keyPressed(key) {

}

function keyReleased(key) {
    
}